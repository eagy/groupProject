package cards;

/**
 * 
 * @author Daniel Eagy
 *
 */
public enum Suit {
	HEARTS, SPADES, CLUBS, DIAMONDS;
}
